const dev={
    username: 'root',
    password: '',
    siteDomain: 'http://127.0.0.1',
    origin: 'http://localhost:8080',
    port:5000
}
const pro={
    username: 'root',
    password: '',
    siteDomain: 'http://127.0.0.1',
    origin: 'http://localhost:8080',
    port:5000
}
const defaultConfig=process.env.NODE_ENV==='production'?pro:dev
module.exports =defaultConfig
