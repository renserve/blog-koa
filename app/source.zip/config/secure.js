'use strict';
const {username,password}=require('@config/config')
module.exports = {
  db: {
    database: 'cms',
    host: '127.0.0.1',
    dialect: 'mysql',
    port: 3306,
    username: username,
    password: password,
    logging: false,
    timezone: '+08:00'
  },
  secret:
      '\x88W\xf09\x91\x07\x98\x89\x87\x96\xa0A\xc68\xf9\xecJJU\x17\xc5V\xbe\x8b\xef\xd7\xd8\xd3\xe6\x95*4'
};
