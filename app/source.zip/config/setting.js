const path = require('path');
const {siteDomain, port} = require('@config/config')
const debug=process.env.NODE_ENV==='production'?false:true
module.exports = {
    port: port,
    siteDomain: siteDomain,
    countDefault: 10,
    pageDefault: 0,
    apiDir: 'api',
    // 指定工作目录，默认为 process.cwd() 路径
    baseDir: path.resolve(__dirname, '../'),
    // debug 模式
    debug:debug,
    // refreshExp 设置refresh_token的过期时间，默认一个月
    accessExp:60 * 60 * 24 * 7, // 1h 单位秒
    refreshExp: 60 * 60 * 24 * 30,
    // 暂不启用插件
    pluginPath: {
        // // plugin name
        // poem: {
        //   // determine a plugin work or not
        //   enable: true,
        //   // path of the plugin
        //   path: "app/plugin/poem",
        //   // other config
        //   limit: 2
        // },
    }
};
